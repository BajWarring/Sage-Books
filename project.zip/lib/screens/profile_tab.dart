// lib/screens/profile_tab.dart

import 'package:flutter/material.dart';

// --- NEW: Colors from HTML mockup ---
const Color _primaryOrange = Color(0xFFFF6B00);
const Color _textDark = Color(0xFF212121);
const Color _textMedium = Color(0xFF5F5F5F);
const Color _bgLightGrey = Color(0xFFF9F9F9);
const Color _bgWhite = Color(0xFFFFFFFF);
// --- End New Colors ---

class ProfileTab extends StatelessWidget {
  final VoidCallback onBackTapped;

  const ProfileTab({super.key, required this.onBackTapped});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bgLightGrey,
      appBar: _buildAppBar(context),
      body: _buildProfileContent(context),
    );
  }

  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return AppBar(
      backgroundColor: _primaryOrange,
      elevation: 1.0,
      shadowColor: Colors.black.withAlpha(25),
      leading: IconButton(
        icon: const Icon(Icons.arrow_back, color: Colors.white),
        onPressed: onBackTapped, // Triggers the slide-out animation
      ),
      title: const Text(
        'My Profile',
        style: TextStyle(
          color: Colors.white,
          fontSize: 18,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  Widget _buildProfileContent(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 90,
            height: 90,
            decoration: BoxDecoration(
              color: _bgWhite,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withAlpha(25),
                  blurRadius: 10,
                  offset: const Offset(0, 4),
                )
              ],
            ),
            child: const Icon(
              Icons.person,
              size: 45,
              color: _primaryOrange,
            ),
          ),
          const SizedBox(height: 15),
          const Text(
            'Profile', // Placeholder
            style: TextStyle(
              fontSize: 20,
              color: _textDark,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 5),
          const Text(
            'manjot.gill@example.com', // Placeholder
            style: TextStyle(
              fontSize: 14,
              color: _textMedium,
            ),
          ),
          const Text(
            '+91 98765 43210', // Placeholder
            style: TextStyle(
              fontSize: 14,
              color: _textMedium,
            ),
          ),
        ],
      ),
    );
  }
}