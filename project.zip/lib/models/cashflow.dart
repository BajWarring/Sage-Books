// lib/models/cashflow.dart

enum CashFlow { cashIn, cashOut }
